import { DayShorterPipe } from './day-shorter.pipe';

describe('DayShorterPipe', () => {
  it('create an instance', () => {
    const pipe = new DayShorterPipe();
    expect(pipe).toBeTruthy();
  });
});
