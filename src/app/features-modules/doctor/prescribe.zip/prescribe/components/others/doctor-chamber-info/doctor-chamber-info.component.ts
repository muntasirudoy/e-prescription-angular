import { Component } from '@angular/core';

@Component({
  selector: 'app-doctor-chamber-info',
  standalone: true,
  imports: [],
  templateUrl: './doctor-chamber-info.component.html',
  styleUrl: './doctor-chamber-info.component.scss'
})
export class DoctorChamberInfoComponent {

}
