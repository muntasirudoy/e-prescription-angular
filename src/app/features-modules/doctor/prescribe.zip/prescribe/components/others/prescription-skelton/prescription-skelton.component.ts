import { Component } from '@angular/core';

@Component({
  selector: 'app-prescription-skelton',
  standalone: true,
  imports: [],
  templateUrl: './prescription-skelton.component.html',
  styleUrl: './prescription-skelton.component.scss'
})
export class PrescriptionSkeltonComponent {

}
