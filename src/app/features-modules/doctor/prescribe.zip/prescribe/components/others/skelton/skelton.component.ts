import { Component } from '@angular/core';

@Component({
  selector: 'app-skelton',
  standalone: true,
  imports: [],
  templateUrl: './skelton.component.html',
})
export class SkeltonComponent {}
