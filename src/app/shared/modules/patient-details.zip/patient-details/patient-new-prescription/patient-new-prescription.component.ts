import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-new-prescription',
  templateUrl: './patient-new-prescription.component.html',
  styleUrl: './patient-new-prescription.component.scss',
})
export class PatientNewPrescriptionComponent {
  prescriptionListDetails = [];
  openPdfDialog(id: any) {}
}
