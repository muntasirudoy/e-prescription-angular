import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-medical-records',
  templateUrl: './patient-medical-records.component.html',
  styleUrls: ['./patient-medical-records.component.scss']
})
export class PatientMedicalRecordsComponent {

}
