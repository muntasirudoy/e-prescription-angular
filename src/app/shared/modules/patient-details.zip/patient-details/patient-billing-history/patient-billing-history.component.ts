import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-billing-history',
  templateUrl: './patient-billing-history.component.html',
  styleUrls: ['./patient-billing-history.component.scss']
})
export class PatientBillingHistoryComponent {

}
