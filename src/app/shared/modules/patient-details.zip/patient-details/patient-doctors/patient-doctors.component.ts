import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-doctors',
  templateUrl: './patient-doctors.component.html',
  styleUrls: ['./patient-doctors.component.scss']
})
export class PatientDoctorsComponent {

}
